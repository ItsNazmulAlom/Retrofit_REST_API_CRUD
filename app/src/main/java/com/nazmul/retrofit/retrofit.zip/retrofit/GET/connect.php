<?php 
// define('host', 'localhost');
// define('user', 'cseiiucc_user');
// define('pass', 'c131051cse#');
// define('db', 'cseiiucc_user');

// $conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
define('host', 'localhost');
define('user', 'nkriecou_rectrofit');
define('pass', 'rectrofit');
define('db', 'nkriecou_rectrofit');

$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
// if($conn == true){
//     echo "success";
// }
?>