<?php 
define('host', 'localhost');
define('user', 'nkriecou_rectrofit');
define('pass', 'rectrofit');
define('db', 'nkriecou_rectrofit');

$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
// if($conn == true){
//     echo "success";
// }

?>